#!/usr/bin/env bash

run --mirror https://dl.nwjs.io/ --chrome-app .