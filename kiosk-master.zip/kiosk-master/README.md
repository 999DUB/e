## Setup
-  get OSX developer certificate
- `brew install wine`
- `npm install`

## Use

Build: `npm run build` then .zip the `/dist` folder for upload to the Chrome Developer Console.

## Changelog

See CHANGELOG.md